# Lesson format

Formats for the parts of a lesson. Read this once per chat, before the first lesson message.

## Label lessons and prompts

- **Title.** Open each part with one bold line in this shape, in the learner’s language: `Lesson 20 · At school · part 1 of 2`. The lesson number is the map’s and never changes. Leave out “part 1 of 1” when a lesson has a single part.
- **Title once.** When a part starts with the vocabulary table, the table’s heading is the title and no title line goes above it. When a part starts with review, the title line opens the review and the table’s heading repeats it later.
- **No commentary on the plan.** State the title and teach. Leave out remarks about how the lesson is divided, why a part has the number of words it has, or what the map says, unless the learner asks. One short line before the table, such as “Here are the new words”, is fine.
- **Same words every time.** Use one word for “lesson”, one for “part”, and one name for each lesson through the whole course. Take them from the **Labels** line and the **Lessons** list in `course.md`.
- **Prompts.** In review and written translation, put the counter on its own bold line, such as **Review 1 of 5** or **Exercise 3 of 7**, and the sentence to translate as plain text under it, with a blank line between them. Keep the prompt out of blockquotes so it reads at full strength. Say “Translate into Mandarin” only before the first prompt of each part of the lesson.

## Write Mandarin the same way everywhere

Outside the vocabulary table, every piece of Mandarin follows one pattern: **Hanzi in bold**, *pinyin in italics*, meaning in plain text.

- A chunk or a corrected sentence takes three lines: the Hanzi in bold, the pinyin in italics under it, and the meaning in the learner’s language under that.
- A word inside a sentence is written inline: **超市** (*chāoshì*, supermarket).
- Reading texts stay as plain Hanzi, with no pinyin.
- Never italicize or strike through Hanzi.

## Format each vocabulary table

Use the selectable HTML table below whenever the chat can display it alongside the message. Copy the whole block character for character, including the `<style>` with its `@font-face` rule. Change only three things: the heading, the rows, and the localized column headers. The heading is the lesson title line, such as `Lesson 10 · Dates and weekdays · part 1 of 2`. Keep every Hanzi inside `<span lang="zh-Hans">`. If the tool that renders the table comes with its own design guidance, this template still wins: don’t restyle it, simplify it, or drop the font.

The Hanzi use a handwriting-style Kaiti in mainland standard forms, so the first shape the learner sees is close to what they will write in a notebook. The font loads from the web, or from the learner’s computer when it is installed there.

```html
<section id="mandarinmaxxing-vocab">
  <h2>Lesson 13 · Shopping and paying · part 1 of 3</h2>
  <table>
    <thead><tr><th scope="col">Hanzi</th><th scope="col">Pinyin</th><th scope="col">Meaning</th></tr></thead>
    <tbody><tr><td><span lang="zh-Hans">商店</span></td><td>shāngdiàn</td><td>shop</td></tr></tbody>
  </table>
</section>
<style>
  @font-face {
    font-family: "Mandarinmaxxing Kaiti";
    src: local("LXGW WenKai GB"), local("LXGW WenKai GB Lite"),
      url("https://cdn.jsdelivr.net/gh/aveduardo-br/mandarinmaxxing@338b81599301cc40b92b882af7d7e301efa15c7b/skills/mandarinmaxxing/fonts/kaiti-hsk-1-6.woff") format("woff");
    font-display: swap;
  }
  #mandarinmaxxing-vocab { --soft: var(--text-secondary, color-mix(in srgb, currentColor 65%, transparent)); --line: var(--border, color-mix(in srgb, currentColor 15%, transparent)); padding: 4px 0 24px; }
  #mandarinmaxxing-vocab h2 { font-size: 16px; font-weight: 500; margin: 0 0 8px; }
  #mandarinmaxxing-vocab table { width: 100%; border-collapse: collapse; }
  #mandarinmaxxing-vocab th, #mandarinmaxxing-vocab td { text-align: left; font-weight: 400; padding: 10px 64px 10px 0; border-bottom: 1px solid var(--line); vertical-align: middle; user-select: text; }
  #mandarinmaxxing-vocab th { font-size: 13px; font-weight: 500; color: var(--soft); }
  #mandarinmaxxing-vocab th:nth-child(-n+2), #mandarinmaxxing-vocab td:nth-child(-n+2) { width: 1%; white-space: nowrap; }
  #mandarinmaxxing-vocab td:nth-child(2) { color: var(--soft); }
  #mandarinmaxxing-vocab span[lang="zh-Hans"] { font-family: "Mandarinmaxxing Kaiti", "Kaiti SC", "STKaiti", "KaiTi", serif; font-size: 32px; line-height: 1.2; font-synthesis: none; }
</style>
```

If the chat can’t embed HTML, use a selectable Markdown table in the message. Enlarge Hanzi through inline math where rendering and selection are confirmed, for example `$\LARGE\text{公交车}$` in Codex desktop. Use bold Hanzi when the interface supports standard text formatting only.

## Respond to a written translation

Use plain Markdown for all feedback and the Mandarin pattern above. Blockquotes are reserved for one thing: showing back what the learner wrote in a correction.

- **Correct and natural.** Confirm briefly and move to the next prompt. Accept any natural version that meets the request. If a valid alternative uses a different expression, acknowledge it and bring the intended chunk back in a later prompt.
- **Correct meaning, noticeably unnatural phrasing.** Acknowledge that the meaning is right. Show a more natural version in Hanzi with pinyin directly below it and briefly explain the change.
- **Incorrect.** Use this order. First a short opener and “You wrote:”, then the learner’s whole answer in a blockquote. Next, one line that points only at the part that went wrong: the word or chunk to use in its place in bold, its pinyin in italics, and a short reason. Use one such line per error. Then the full corrected sentence once, as bold Hanzi, italic pinyin, and plain meaning on three lines. Follow with the next prompt. Leave out a word-by-word breakdown of the parts the learner got right.

## Reading, when there is no voice provider

Send one message in this order:

- A bold title in the learner’s language with its number, such as **Reading 1**.
- The text: three to six short Mandarin sentences in plain Hanzi, as someone telling a small story or describing their day, or a short exchange between two people. No pinyin and no translation.
- A bold line such as **Your turn**, then the task in the learner’s language.

The task is to rewrite the text with a few changes you name, for example another day, another thing to buy, another price. Skip comprehension questions here: the learner can see the text, so they only test finding a word. Correct the rewrite with the same format as a written translation.

Use one or two of these per part. Use every new word of the part across the texts.

## Listening, with a voice provider

1. **Draft the script.** One speaker, three to six short sentences: someone telling what they did, what they want, or what happened, in a concrete scene. Aim for 15 to 20 seconds at a clear speaking pace. Keep it a single voice; a conversation would need one generation per line.
2. **Review before generating.** Read the script through. Check that the Mandarin sounds natural, the part’s new words fit the scene, and the questions can be answered from what’s said.
3. **Generate once.** Make one clip with the voice saved for the course, asking the provider for a single take. On the first clip of a course, choose the voice and save it in `course.md`: with ElevenLabs, use Sarah (voice ID `EXAVITQu4vr4xnSDxMaL`) unless the learner asks for another; with another provider, or if Sarah isn’t in the voice list, pick one clear, neutral voice from the provider’s own list. Set the language to Chinese when the provider has that setting. Never run a generation again to retry or to get a variation unless the learner asks: each run spends their credits.
4. **Send.** Put the questions in the same message as the clip, so the learner can read them before playing. Label it by number and scene, such as **Audio 1 · At the tea shop**. Keep the script out of the message.
5. Ask what happened, what the speaker wanted, or what a chunk meant in context. Ask the learner to answer all the questions together, then mark each answer correct or incorrect. Share the script with pinyin and a translation only if they ask after answering.
